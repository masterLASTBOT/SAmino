# SAmino Lib
libarry to make a bots for Amino chat app

## Installation
``pip install SAmino``

## Not for Khackers

Powered By [S-Amino](http://aminoapps.com/c/SirLez0) Community!